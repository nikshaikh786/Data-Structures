#define MAX 5
#include <stdio.h>
#include <stdlib.h>
typedef struct {
	int data[MAX],rear,front;
	}queue;
	
void initialize(queue *q)
{
	q->rear=q->front=-1;
	}

int isEmpty(queue *q)
{
	return ((q->front==-1)?1:0);
	} 
	
int isFull(queue *q)
{
	return ((q->rear==MAX-1)?1:0);
	} 
	
void enqueue(queue *q,int n)
{
	if(q->front==-1)
	q->front=0;
	q->data[++(q->rear)]=n;
		}
	
int dequeue (queue *q)
{
	int d;
	d=q->data[q->front++];
		}

int search(queue *q,int d)
{
	int i,flag=0;
	for(i=q->front;i<=q->rear;i++)
	{
		if(q->data[i]==d)
		flag=1;
		}
	return (flag==1?1:0);
	}
	
int availableSpace(queue *q)
{
	if(q->front==-1)
		return MAX;
	return (MAX-q->rear-1);
}

	
void display(queue *q)
{
	int i;
	if(isEmpty(q))
	printf("\n\tThe Queue is Empty");
	else
	{
	printf("\n\t\tFront = %d \t Rear = %d\n",q->front,q->rear);
	printf("\n\tThe content of queue :\n \n\t");
	for(i=q->rear;i>=q->front;i--)
	printf("\t%d",q->data[i]);
		}
	}
	
int main()
{
queue q;
int option,num;
initialize(&q);
	while(1) {
	printf("\n\n\t\t\t*MENU*\n\t1.Enqueue\n\t2.Dequeue\n\t3.Search\n\t4.Available Space\n\t5.Display\n\t6.Exit");
	printf("\n\n\t\tEnter your choice :: ");
	scanf("%d",&option);
	switch(option)
	{
	case 1:
	if(isFull(&q))
	printf("\n\tCannot perform Enqueue operation.\n\tThe queue is Full.");
	else {
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	enqueue(&q,num);
	printf("\n\t%d is inserted successfully ",num);
	}
	break;
	case 2:
	if(isEmpty(&q))
		printf("\n\tCannot perform Dequeue operation.\nThe queue is Empty.");
	else {
	num=dequeue(&q);
	printf("\n\t%d is deleted successfully.",num);
	}
	break;
	case 3:
	if(isEmpty(&q))
		printf("\n\tThe queue is Empty.");
	else {
	printf("\n\tEnter the number you want to search : ");
	scanf("%d",&num);
	if(search(&q,num))
	printf("\n\t%d is present.",num);
	else
	printf("\n\t%d is not present",num);
	}
	break;
	case 4:
	printf("\n\tAvailable Space : %d elements can be inserted\n",availableSpace(&q));
	break;
	case 5:
	display(&q);
	break;
	case 6:
	exit(0);
	default:
	printf("\n\tInvalid option...\n\tPlease choose valid option");
		}
	}
return 0;
}