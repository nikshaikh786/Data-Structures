#define MAX 5
#include <stdio.h>
#include <stdlib.h>
typedef struct {
	int data[MAX],rear,front;
	}queue;
	
void initialize(queue *q)
{
	q->rear=q->front=-1;
	}

int isEmpty(queue *q)
{
	return ((q->front==-1)?1:0);
	} 
	
int isFull(queue *q)
{
	return ((q->front==(q->rear+1)%MAX)?1:0);
	} 
	
void enqueue(queue *q,int n)
{
	if(isEmpty(q))
	q->front=0;
	q->data[++q->rear]=n;
	}
	
int dequeue (queue *q)
{
	int d;
	d=q->data[q->front];
	if(q->rear==q->front)
	initialize(q);//Resets the value of Front and Rear to -1
	else
	q->front=(q->front+1)%MAX;
return d;
}

int search(queue *q,int d)
{
	int i,flag=0;
	for(i=q->front;i!=q->rear;i=(i+1)%MAX) //This loop does not compare the last element
	{
		if(d==q->data[i])
		flag=1;
		}
		if(d==q->data[i]) //For last element comparison
			flag=1;
	return ((flag==1)?1:0);
	}
	
int availableSpace(queue *q)
{
	if(q->front==-1)
		return MAX;
	return (MAX-q->rear+q->front-1);
}
	
void display(queue *q)
{
	int i;
	if(isEmpty(q))
	printf("The Queue is Empty");
	else
	{
	printf("\t\tFront = %d\t Rear = %d",q->front,q->rear);
	printf("\n\tThe content of queue : \n");
	for(i=q->front;i!=q->rear;i=(i+1)%MAX)//This loop does not print the last element 
	printf("\t %d \n",q->data[i]);
	printf("\t %d \n",q->data[i]);//This is for printing the last element
		}
	}
	
int main()
{
queue q;
int option,num;
initialize(&q);
	while(1) {
	printf("\n\n\t\t\t*MENU*\n\t1.Enqueue\n\t2.Dequeue\n\t3.Search\n\t4.Available Space\n\t5.Display\n\t6.Exit");
	printf("\n\n\t\tEnter your choice :: ");
	scanf("%d",&option);
	switch(option)
	{
	case 1:
	if(isFull(&q))
	printf("\n\tCannot perform Enqueue operation.\n\tThe queue is Full.");
	else {
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	enqueue(&q,num);
	printf("\t%d is inserted successfully ",num);
	}
	break;
	case 2:
	if(isEmpty(&q))
		printf("\n\tCannot perform Dequeue operation.\nThe queue is Empty.");
	else {
	num=dequeue(&q);
	printf("\n\t%d is deleted successfully.",num);
	}
	break;
	case 3:
	if(isEmpty(&q))
		printf("\n\tThe queue is Empty.");
	else {
	printf("\n\tEnter the number you want to search : ");
	scanf("%d",&num);
	if(search(&q,num))
	printf("\t%d is present.",num);
	else
	printf("\t%d is not present",num);
	}
	break;
	case 4:
	printf("\n\tAvailable Space : %d elements can be inserted\n",availableSpace(&q));
	break;
	case 5:
	display(&q);
	break;
	case 6:
	exit(0);
	break;
	default:
	printf("\n\tInvalid option...\n Please choose valid option\n");
		}
	}
return 0;
}