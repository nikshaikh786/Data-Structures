/* 	
Experiment 1 : 
Name : Khan Israr Ahmed Ali Husain
Roll No.: 18CO30

Description:
In this program wee have used modular approach i.e we wrote different 
functions for different tasks like to 
1. Check Palindrome
2. Find Factorial
3. Print Fibonacci series
*/

#include <stdio.h>
int factorial(int n)
{	int i=1,fact=1;
		for(i=1;i<=n;i++)
		{
		fact=fact*i;
		}
		return fact;
}

void palindrome(int n)
{	
	int temp=n,rev=0;
	while(n!=0)
	{
		rev=rev*10+(n%10);
		n/=10;
		}
	(temp==rev)?printf("\n\t%d is a Palindrome.",temp):printf("\n\t%d is not a Palindrome.",temp);
	}
	
void fibo(int limit)
{
	int a=0,b=1,c=0;
	if(limit>=0)
	{
	printf("\n\tFibonacci Series upto %d :\n",limit);
	while(a<=limit)
	{
		printf("\t%d",a);
		c=a+b;
		a=b;
		b=c;
		}
	}
	else
	printf("Please Enter Whole Number Only.");
}

int main()
{
int factorial(int );
void palindrome(int );
void fibo(int );
int option,n;
while(1)
{
printf("\n\t\t*MENU*\n1.Factorial\n2.Palindrome\n3.Fibonacci Series\n4.Exit\n\n\tSelect Any One Option :  ");
scanf("%d",&option);
if(option==4) // This statement exits the program. Hence there is no extra case 4.
break;
switch(option)
{
case 1:
printf("\nEnter the Number : ");
scanf("%d",&n);
printf("\n\tThe Factorial of %d is %d.\n\n",n,factorial(n));
break;
case 2:
printf("\nEnter the Number : ");
scanf("%d",&n);
palindrome(n);
printf("\n\n");
break;
case 3:
printf("\nEnter the limit : ");
scanf("%d",&n);
fibo(n);
printf("\n\n");
break;
default:
printf("Please Select From the Above Options Only.");
	}  
}
return 0;
}
