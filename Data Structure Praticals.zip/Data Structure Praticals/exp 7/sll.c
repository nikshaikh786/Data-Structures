/*
 * Experiment No.7:
 * Aim : Implementation of Singly Linked List.
 * Name : Khan Israr Ahmed Ali Husain
 * Roll No. : 18CO30
	*/
#include <stdio.h>
#include <stdlib.h>

struct sll{
	int data;
	struct sll *next;
};

struct sll* insertBegin(struct sll *h,int d)
{	
	struct sll *p=(struct sll *)malloc(sizeof(struct sll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		p->data=d;
	if(h==NULL)	
		p->next=NULL;
	else
		p->next=h;
		h=p;
		printf("\n\t%d is inserted successfully ",d);
	}
	return h;
}

struct sll* insertEnd(struct sll *h,int d)
{	
	struct sll *tmp;
	struct sll *p=(struct sll *)malloc(sizeof(struct sll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		p->data=d;	
		p->next=NULL;
		tmp=h;
		while(tmp->next!=NULL)
			tmp=tmp->next;
		tmp->next=p;
		printf("\n\t%d is inserted successfully ",d);
	}
	return h;
}


struct sll* insertBefore(struct sll *h,int d)
{	
	int num; 
	struct sll *tmp1,*tmp2;
	struct sll *p=(struct sll *)malloc(sizeof(struct sll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		printf("\n\tEnter the number which you want to insert : ");
		scanf("%d",&num);
		p->data=num;	
		tmp1=h;
		while((tmp1!=NULL)&&(tmp1->data!=d))
		{
			tmp2=tmp1;
			tmp1=tmp1->next;
		}
		if(tmp1==NULL)
			printf("\n\tElement is not found.");
		else
		{
			p->next=tmp2->next;
			tmp2->next=p;
			printf("\n\t%d is inserted successfully ",num);
		}
	}
	return h;
}

struct sll* insertAfter(struct sll *h,int d)
{	
	int num; 
	struct sll *tmp;
	struct sll *p=(struct sll *)malloc(sizeof(struct sll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		printf("\n\tEnter the number which you want to insert : ");
		scanf("%d",&num);
		p->data=num;	
		tmp=h;
		while((tmp!=NULL)&&(tmp->data!=d))
			tmp=tmp->next;
		if(tmp==NULL)
			printf("\n\tElement is not found.");
		else
		{
			p->next=tmp->next;
			tmp->next=p;
			printf("\n\t%d is inserted successfully ",num);
		}
	}
	return h;
}


void display(struct sll *h)
{
	struct sll *tmp=NULL;
	if(h==NULL)
		printf("\n\tList is Empty");
	else
	{
		printf("\n\tData of List :\n\n");
		tmp=h;
		while(tmp!=NULL)
		{
			printf("\t%d",tmp->data);
			tmp=tmp->next;
		}
	}
}

struct sll* deleteBegin(struct sll *h)
{	
	struct sll *tmp=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		tmp=h;
		printf("\n\t\t%d is deleted successfully..",tmp->data);
		h=tmp->next;
		free(tmp);
	}
	return h;	
}

struct sll* deleteEnd(struct sll *h)
{	
	struct sll *tmp1=NULL,*tmp2=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		tmp1=h;
		while(tmp1->next!=NULL)
		{	
		tmp2=tmp1;
		tmp1=tmp1->next;
		
		}
		printf("\n\t\t%d is deleted successfully..",tmp1->data);
		tmp2->next=NULL;
		free(tmp1);
	}
	return h;	
}

struct sll* deleteBefore(struct sll *h)
{	
	int num;
	struct sll *tmp1=NULL,*tmp2=NULL,*tmp3=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		printf("\n\tEnter the element Before which  you want to Delete : ");
		scanf("%d",&num);
		tmp1=h;
		while((tmp1!=NULL)&&(tmp1->data!=num))
		{
			tmp2=tmp1;
			tmp1=tmp1->next;
		}
		
		if(tmp1==NULL)
			printf("\n\tElement is not found");
		else {
			tmp3=h;
			while(tmp3->next!=tmp2)
				tmp3=tmp3->next;
			tmp3->next=tmp2->next;
		printf("\n\t\t%d is deleted successfully..",tmp2->data);
		free(tmp2);
	}
	}
	return h;	
}

struct sll* deleteAfter(struct sll *h)
{	
	int num;
	struct sll *tmp1=NULL,*tmp2=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		printf("\n\tEnter the element after which  you want to Delete : ");
		scanf("%d",&num);
		tmp1=h;
		while((tmp1!=NULL)&&(tmp1->data!=num))
		tmp1=tmp1->next;
		if(tmp1==NULL)
			printf("\n\tElement is not found");
		else {
			tmp2=tmp1->next;
			tmp1->next=tmp2->next;
		printf("\n\t\t%d is deleted successfully..",tmp2->data);
		free(tmp2);
	}
	}
	return h;	
}

struct sll* search(struct sll *h,int d)
{
	struct sll *tmp=NULL;
	if(h==NULL)
	printf("\n\tList is Empty...");
	else
	{
		tmp=h;
	while((tmp!=NULL)&&(tmp->data!=d))
	{tmp=tmp->next;}
	
	if(tmp==NULL)
		printf("\n\t%d is not present",d);
	else
		printf("\n\t%d is present",d);
	}
	return h;
}

int main()
{
struct sll *h=NULL;
int option,num;
	while(1) {
	printf("\n\n\t\t\t*MENU*\n\n\t1. Insert at Beginning\n\t2. Insert at End\n\t3. Insert Before a Node\n\t4. Insert After a Node\n\t5. Delete from Beginning\n\t6. Delete from End\n\t7. Delete Before a Node\n\t8. Delete After a Node\n\t9. Search\n\t10.Display\n\t11.Exit");
	printf("\n\n\t\tEnter your choice :: ");
	scanf("%d",&option);
	switch(option)
	{
	case 1:
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	h=insertBegin(h,num);
	break;
	case 2:
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	h=insertEnd(h,num);
	break;
	case 3:
	printf("\n\tEnter the Element before which you want to Insert : ");
	scanf("%d",&num);
	h=insertBefore(h,num);
	break;
	case 4:
	printf("\n\tEnter the Element after which you want to Insert : ");
	scanf("%d",&num);
	h=insertAfter(h,num);
	break;

	case 5:
	h=deleteBegin(h);
	break;
	
	case 6:
	h=deleteEnd(h);
	break;
	case 7:
	h=deleteBefore(h);
	break;
	case 8:
	h=deleteAfter(h);
	break;
	case 9:
	printf("\n\tEnter the number you want to search : ");
	scanf("%d",&num);
	h=search(h,num);
	break;
	case 10:
	display(h);
	break;
	case 11:
	exit(0);
	break;
	default:
	printf("\n\tInvalid option...\n Please select valid option\n");
		}
	}
return 0;
}
