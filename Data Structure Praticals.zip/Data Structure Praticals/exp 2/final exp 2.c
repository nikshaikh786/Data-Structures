/*
 * Experiment No.2:
 * Aim : Implement stack using arrays.
 * Name : Khan Israr Ahmed Ali Husain
 * Roll No. : 18CO30
 
	Description :
 * A stack is a linear data structure in which the data is inserted and 
  deleted from the same end. This end is called top of the stack.
 * 1. The process of inserting data to Stack is referred as PUSH.
 * 2. The process of retrieving data from Stack is referred as POP.
 * 3. Displaying the top most element of Stack is called PEEK. 
 */

#include <stdio.h>
#include <stdlib.h>
#define MAX 5
struct stack {
	int data[MAX];
	int top;
	};
	
void initialize(struct stack *s)
{
	s->top=-1;
	}

int isEmpty(struct stack *s)
{
	return ((s->top==-1)?1:0);
	}
	
int isFull(struct stack *s)
{
	return ((s->top==(MAX-1))?1:0);
	}
	
int push(struct stack *s,int d)
{
	if(isFull(s)==1)
	return 0;
	else
	return (s->data[++(s->top)]=d);
	}
	
int pop(struct stack *s)
{
	if(isEmpty(s)==1)
	return 0;
	else
	return (s->data[(s->top)--]);
	}
	
int peek(struct stack *s)
{
	if(isEmpty(s)==1)
	return 0;
	return (s->data[s->top]);
	}
	
void display(struct stack *s)
{
	int counter;
	if(isEmpty(s)==1)
	return 0;
	for(counter=s->top;counter>=0;counter--)
	{
		printf("\n\t%d",s->data[counter]);
		}
		printf("\n\n");
	}

int main()
{
	void initialize(struct stack *);
	int isEmpty(struct stack *);
	int isFull(struct stack *);
	int push(struct stack *,int);
	int pop(struct stack *);
	int peek(struct stack *);
	void display(struct stack *);
	struct stack s;
	int option,d,ans;
	initialize(&s);
	while(1)
	{
		printf("\t\tMENU\n1. Push\n2. Pop\n3. Peek\n4. Display\n5. Exit");
		printf("\n\n\tEnter Your Choice :: ");
		scanf("%d",&option);
		switch(option)
		{
			case 1:
			printf("\nEnter the data to be pushed : ");
			scanf("%d",&d);
			if(push(&s,d)==0)
			printf("\tCannot push because stack is full\n\n");
			else
			printf("\n\t%d is pushed successfully.\n\n",s.data[s.top]);
			break;
			case 2:
			ans=pop(&s);
			if(ans==0)
			printf("Cannot pop, because Stack is empty\n\n");
			else
			{
				printf("The popped data is %d\n\n",ans);
				}
			break;
			case 3:
			if(peek(&s)==0)
			printf("The stack is Empty.\n\n");
			else
			printf("The topmost data is %d\n\n",peek(&s));
			break;
			case 4:
			if(isEmpty(&s)==1)
			printf("The stack is Empty.\n\n");
			printf("The data of stack :");
			display(&s);
			break;
			case 5:
			exit(0);
			break;
			default:
			printf("Choose valid options only.\n\n");
			}
		}
	return 0;	
	}
