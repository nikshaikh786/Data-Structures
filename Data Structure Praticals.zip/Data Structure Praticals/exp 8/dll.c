/*
 * Experiment No.8:
 * Aim : Implementation of Doubly Linked List.
 * Name : Khan Israr Ahmed Ali Husain
 * Roll No. : 18CO30
*/
#include <stdio.h>
#include <stdlib.h>

struct dll{
	int data;
	struct dll *next;
	struct dll *prev;
};

struct dll* insertBegin(struct dll *h,int d)
{	
	struct dll *p=(struct dll *)malloc(sizeof(struct dll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		p->data=d;
		p->prev=NULL;
	if(h==NULL)	
		{
		p->next=NULL;
		p->prev=NULL;
	}
	else
		{
			p->next=h;
			h->prev=p;
			}
		h=p;
		printf("\n\t%d is inserted successfully ",d);
	}
	return h;
}

struct dll* insertEnd(struct dll *h,int d)
{	
	struct dll *tmp;
	struct dll *p=(struct dll *)malloc(sizeof(struct dll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{  
		p->data=d;	
		p->next=NULL;
		tmp=h;
		if(h==NULL)
		{
			p->prev=NULL;
			h=p;
		}
		else{
		while(tmp->next!=NULL)
			tmp=tmp->next;
		tmp->next=p;
		p->prev=tmp;
		}
		printf("\n\t%d is inserted successfully ",d);
	}
	return h;
}


struct dll* insertBefore(struct dll *h,int d)
{	
	int num; 
	struct dll *tmp;
	struct dll *extra;
	struct dll *p=(struct dll *)malloc(sizeof(struct dll));
	if(p==NULL)
		printf("\n\tNo enough space available..");
	else
	{
		printf("\n\tEnter the number which you want to insert : ");
		scanf("%d",&num);
		p->data=num;	
		tmp=h;
		while((tmp!=NULL)&&(tmp->data!=d))
			tmp=tmp->next;
		if(tmp==NULL)
			printf("\n\tElement is not found.");
		else
		{
			p->next=tmp;
			p->prev=tmp->prev;
			extra=tmp;
			tmp->prev=p;
			extra=extra->prev;
			extra->next=p;
			printf("\n\t%d is inserted successfully ",num);
		}
	}
	return h;
}


void display(struct dll *h)
{
	struct dll *tmp=NULL;
	if(h==NULL)
		printf("\n\tList is Empty");
	else
	{
		printf("\n\tData of List :\n\n");
		tmp=h;
		while(tmp!=NULL)
		{
			printf("\t%d",tmp->data);
			tmp=tmp->next;
		}
	}
}


void displayRev(struct dll *h)
{
	struct dll *tmp=NULL;
	if(h==NULL)
		printf("\n\tList is Empty");
	else
	{
		printf("\n\n\tData of List in Reverse order :\n\n");
		tmp=h;
		while(tmp->next!=NULL)
			tmp=tmp->next;
		while(tmp!=NULL)
		{
			printf("\t%d",tmp->data);
			tmp=tmp->prev;
		}
		
	}
}

struct dll* deleteBegin(struct dll *h)
{	
	struct dll *tmp=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		tmp=h;
		printf("\n\t\t%d is deleted successfully..",tmp->data);
		h=tmp->next;
		h->prev=NULL;
		free(tmp);
	}
	return h;	
}

struct dll* deleteEnd(struct dll *h)
{	
	struct dll *tmp=NULL;
	struct dll *deallocate=NULL;
	if(h==NULL)
		printf("\n\tCannot delete...\nList is Empty;");
	else
	{
		tmp=h;
		while(tmp->next!=NULL)
		tmp=tmp->next;
		printf("\n\t\t%d is deleted successfully..",tmp->data);
		deallocate=tmp;
		tmp=tmp->prev;
		tmp->next=NULL;
		free(deallocate);
		}
	return h;	
}

struct dll* search(struct dll *h,int d)
{
	struct dll *tmp=NULL;
	if(h==NULL)
	printf("\n\tList is Empty...");
	else
	{
		tmp=h;
	while((tmp!=NULL)&&(tmp->data!=d))
	{tmp=tmp->next;}
	
	if(tmp==NULL)
		printf("\n\t%d is not present",d);
	else
		printf("\n\t%d is present",d);
	}
	return h;
}

int main()
{
struct dll *h=NULL;
int option,num;
	while(1) {
	printf("\n\n\t\t\t*MENU*\n\n\t1. Insert at Beginning\n\t2. Insert at End\n\t3. Insert Before a Node\n\t4. Delete from Beginning\n\t5. Delete from End\n\t6. Search\n\t7.Display\n\t8.Exit");
	printf("\n\n\t\tEnter your choice :: ");
	scanf("%d",&option);
	switch(option)
	{
	case 1:
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	h=insertBegin(h,num);
	break;
	case 2:
	printf("\n\tEnter the number you want to insert : ");
	scanf("%d",&num);
	h=insertEnd(h,num);
	break;
	case 3:
	printf("\n\tEnter the Element before which you want to Insert : ");
	scanf("%d",&num);
	h=insertBefore(h,num);
	break;
	case 4:
	h=deleteBegin(h);
	break;
	
	case 5:
	h=deleteEnd(h);
	break;
	
	case 6:
	printf("\n\tEnter the number you want to search : ");
	scanf("%d",&num);
	h=search(h,num);
	break;
	case 7:
	display(h);
	displayRev(h);
	break;
	case 8:
	exit(0);
	break;
	default:
	printf("\n\tInvalid option...\n Please select valid option\n");
		}
	}
return 0;
}