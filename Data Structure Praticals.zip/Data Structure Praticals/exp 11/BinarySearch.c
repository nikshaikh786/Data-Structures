/* Experiment No. : 11
 * Title : Implementation of Binary Search
 * Name : Khan Israr Ahmed Ali Husain
 * Roll No. : 18CO30
	*/

#include <stdio.h>
#include <stdlib.h>
void binarySearch(int *num,int key)
{
	int lower=0,upper=5,mid,flag=0;
	for(mid=(lower+upper)/2;lower<=upper;mid=(lower+upper)/2)
	{
		if(key==num[mid])
		{
			flag=1;
			break;
		}
		else if(key>num[mid])
			lower=mid+1;
		else
			upper=mid-1;
	}
	flag==1?printf("\n\t%d is present",key):printf("\n\t%d is not present",key);
}

int main()
{
	int *num,i,key,size,ch;
	while(1){
	printf("\n\n\tHow many numbers you want to insert : ");
	scanf("%d",&size);
	num=(int *)malloc(size*sizeof(int));
	printf("\n\tEnter %d numbers : ",size);
	for(i=0;i<size;i++)
		scanf("%d",&num[i]);
	printf("\n\tEnter the number which you want to search : ");
	scanf("\t%d",&key);
	binarySearch(num,key);
	printf("\n\n\tDo you want to try Again : \n\tYes : Press [1]\n\tNo : Press [0];\n\n\t");
	scanf("%d",&ch);
	if(ch==0)
	break;
	}
	
	return 0;
}
